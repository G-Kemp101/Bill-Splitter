DELETE FROM bills;
DELETE FROM userBills;
UPDATE relations SET debt = 0;
