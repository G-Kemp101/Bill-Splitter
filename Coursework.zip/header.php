<html>
<head>
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/bannerAndHeader.css">
	<meta charset="UTF-8">
	<title><?php echo $PageTitle; ?></title>
	<link rel="stylesheet" href="js/jquery-ui.min.css">
<script src="js/external/jquery/jquery.js"></script>
<script src="js/jquery-ui.min.js"></script>
<?php include 'user.php'; $getData = new userclass();?>
