<table id="table">
  <tr>
    <th>BillID</th>
    <th>Bill Description</th>
	<th>Amount</th>
    <th>Paid by</th>
	<?php include 'populateBillTable.php'; ?>
</table>
